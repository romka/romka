$(document).ready(function() {  
  $.tagnetic({div_width: 850, skin: "refrigerator-850", handle: "handle.jpg", handle_width: 280, handle_line: 15});  
});                             