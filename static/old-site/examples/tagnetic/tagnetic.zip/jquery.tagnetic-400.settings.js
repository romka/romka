$(document).ready(function() {  
  $.tagnetic({div_width: 400, skin: "refrigerator-400", handle: "handle.jpg", handle_width: 121, handle_line: 5});  
});                             