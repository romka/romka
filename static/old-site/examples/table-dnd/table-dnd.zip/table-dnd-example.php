<?php
print "Rows:<br>" . str_replace(";", "<br>", $_POST['w']);
?>