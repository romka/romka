﻿<?php
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){

		include("functions.php");
		$test = test_ip();
		$ip = get_ip();
		if($test != 0){
			echo	"-1"; //Нельзя так часто жмакать по кнопке!
		}
		else {	
			include("db_connect.php");
			if(!mysql_query("INSERT INTO ip (`ip`, `date`) VALUES ('" . $ip . "', NOW())")){
				echo  "-2";// Ошибка подключения к БД
			}
			else {	
				mysql_query("SET NAMES 'utf8'");
				if(mysql_query("INSERT INTO messages (m1, m2, date) VALUES ('" . htmlspecialchars($_POST["x1"]) . "', '" . htmlspecialchars($_POST["x2"]) . "', NOW())")){
					$last_id = mysql_insert_id();
	     					
					echo $last_id;
				}	
				else echo "-2";// Ошибка подключения к БД
			}
			include("db_disconnect.php");	
		}	
		
		
		
}
else{
	echo	"You have not permissions to access this page";
}	
?>