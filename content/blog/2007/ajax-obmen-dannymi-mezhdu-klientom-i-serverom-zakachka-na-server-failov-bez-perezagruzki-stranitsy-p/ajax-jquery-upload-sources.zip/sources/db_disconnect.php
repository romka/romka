<?php
        mysql_close($link);
?>