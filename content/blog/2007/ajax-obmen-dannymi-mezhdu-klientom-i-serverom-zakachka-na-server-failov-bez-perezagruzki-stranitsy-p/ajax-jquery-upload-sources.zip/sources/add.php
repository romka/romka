﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
  <head>
    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="ajaxupload.js"></script>
    <script type="text/javascript" src="scriptik.js"></script>
    <link href="css/main.css" rel="stylesheet" type="text/css">
    <title>Пошли всех в жопу!</title>
  </head>
  <body>

 	<center><table width=600 cellpadding=10>
	<form enctype="multipart/form-data" method=post name=jklm>
	<tr><td colspan=2>Тебя утомил занудный начальник? Ты устал от постоянных звонков тупой подружки? 
		Все вокруг тебя постоянно достают и не хотят оставить в покое? Пошли их всех в жопу! 
		<br><br>На этой странице ты можетшь создать персональное сообщение. Например, "КОЛЯ, ИДИ В ЖОПУ" или "БОРИС, ТЫ НЕ ПРАВ!"
		<br><br>Просто передай полученную ссылку всем тем кто тебя достал.
		<br><br>В ближайшее время появится возможность закачивать картинки из интернета (а не только с локального компьютера) и создавать красивые ссылки вроде <nobr>http://boris.idi-v-zhopu.ru.</nobr><br><br></td></tr>
	<tr><td width=50%><br>Здесь укажите текст над картинкой:<br><input name=m1 value="WELCOME TO ASS"><br><br></td>
	<td><br>Здесь укажите текст под картинкой:<br><input name=m2 value="ИДИ В ЖОПУ"><br><br></td></tr>
	<tr><td colspan=2>А здесь, если хотите, выберите свою картинку<br><input type="file" name="img" /></td></tr>
	<tr><td colspan=2><div align=right><input type=button value="Добавить сообщение" onclick="javascript:ajax(this.form.m1.value, this.form.m2.value, this.form);" class=subm></div>
	</td></tr>
	</form>
	</table></center>
	<div id=loading style='position: absolute; left: 50%; width:50%;'><img src=loading.gif></div>
	<br><br>
	<div class="m" style='position: absolute; left: 50%; width:50%; margin-left:-25%;'></div>
	
	<div style='position: absolute; left: 0px; bottom: 0px;'>
	<a href=http://idi-v-zhopu.ru>Обратно...</a>
	</div>
    
	<div style='position: absolute; right: 0px; bottom: 0px;'>
		<!--LiveInternet counter--><script type="text/javascript"><!--
		document.write("<a href='http://www.liveinternet.ru/click' "+
		"target=_blank><img src='http://counter.yadro.ru/hit?t44.6;r"+
		escape(document.referrer)+((typeof(screen)=="undefined")?"":
		";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
		screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
		";"+Math.random()+
		"' alt='' title='LiveInternet' "+
		"border=0 width=31 height=31><\/a>")//--></script><!--/LiveInternet-->
		
	</div>
	<!--
	http://romka.eu
	mne@romka.eu
	-->
  </body>
  </html>
