﻿<?php
//*
function get_ip(){ 
   if ($ip = getenv("HTTP_CLIENT_IP")) return $ip;
   if ($ip = getenv("HTTP_X_FORWARDED_FOR")){
      if ($ip == '' || $ip == "unknown"){
          $ip = getenv("REMOTE_ADDR");
      }
      return $ip;
   }
   if ($ip = getenv("REMOTE_ADDR")) return $ip;
}
function test_ip(){
		include("db_connect.php");
		$ip = get_ip();
		$request = "SELECT COUNT(*) AS c FROM ip WHERE ip = \"" . $ip . "\" AND date > NOW() - INTERVAL '1' minute ";
		$r = mysql_fetch_array(mysql_query($request));
		include("db_disconnect.php");
		if($r['c'] == 0 || $ip == "127.0.0.1" || $ip == "192.168.0.22, 89.179.147.4"){
			return	0;
		}
		else return $r['c'];
}
//*/
//function get_ip(){return "127.0.0.1";}
//function test_ip(){return true;}
?>