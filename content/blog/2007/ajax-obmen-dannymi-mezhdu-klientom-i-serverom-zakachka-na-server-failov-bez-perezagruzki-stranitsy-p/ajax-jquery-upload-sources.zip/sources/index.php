﻿ <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
<title>ЖОПА ТУТ | ASS HERE</title>
<link href="css/main.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
	setlocale(LC_ALL, "ru_RU.UTF8");
	if(!isset($_SERVER['QUERY_STRING']) || !is_numeric($_SERVER['QUERY_STRING']))$id = 1;
	else $id = $_SERVER['QUERY_STRING'];
	
	include	("db_connect.php");
	mysql_query("SET NAMES 'utf8'");
	$request = "SELECT COUNT(*) AS c FROM messages WHERE id = " . $id;
	$r = mysql_fetch_array(mysql_query($request));
	if($r['c'] == 0)$id = 1;

	$request = "SELECT m1, m2 FROM messages WHERE id = " . $id;
	$r = mysql_fetch_array(mysql_query($request));
	$img = "cartman.jpg";
	if(file_exists("./uploadimages/" . $id . ".jpg"))$img = "./uploadimages/" . $id . ".jpg";
	if(file_exists("./uploadimages/" . $id . ".jpeg"))$img = "./uploadimages/" . $id . ".jpeg";
	if(file_exists("./uploadimages/" . $id . ".png"))$img = "./uploadimages/" . $id . ".png";
	if(file_exists("./uploadimages/" . $id . ".gif"))$img = "./uploadimages/" . $id . ".gif";
	
	if(isset($_GET['alias']))echo $_GET['alias'];
?>
	<br><br><br><br><br><br><center><div><?php print $r['m1']; ?>
		<br><img src=<?php echo $img; ?>><br>
	<?php print $r['m2']; ?></div></center>
<?php		
	include	("db_disconnect.php");
?>	
	<div style='position: absolute; left: 0px; bottom: 0px;'>
	<a href=add.php>Что за?..</a>
	</div>
	
	<div style='position: absolute; right: 0px; bottom: 0px;'>
		<!--LiveInternet counter--><script type="text/javascript"><!--
		document.write("<a href='http://www.liveinternet.ru/click' "+
		"target=_blank><img src='http://counter.yadro.ru/hit?t44.6;r"+
		escape(document.referrer)+((typeof(screen)=="undefined")?"":
		";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
		screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
		";"+Math.random()+
		"' alt='' title='LiveInternet' "+
		"border=0 width=31 height=31><\/a>")//--></script><!--/LiveInternet-->
		
	</div>
<!--
http://romka.eu
mne@romka.eu
-->
</body>
</html>