<?php
include "functions.php";
$test = test_ip();
if($test >= 2){
	$arr = array ('result'=>'IMG_UPLOAD_ERROR_4');
	exit (json_encode($arr));
}	

$id = $_GET['k'];
$id = preg_replace("/\D/", "", $id);
if(intval($id)!= $id){
	$arr = array ('result'=>"IMG_UPLOAD_ERROR_3:" . intval($id) . ":" . $id);
	exit (json_encode($arr));
}	
$id = intval($id);


if(is_uploaded_file($_FILES['img']['tmp_name'])){
	if($_FILES['img']['type'] != "image/bmp" && $_FILES['img']['type'] != "image/jpeg" && $_FILES['img']['type'] != "image/gif" && $_FILES['img']['type'] != "image/png" && $_FILES['img']['type'] != "image/pjpeg"){
		$arr = array ('result'=>"IMG_UPLOAD_ERROR_WRONG_FILE_TYPE");
		exit (json_encode($arr));
	}
	if($_FILES['img']['size'] >= 100000){
		$arr = array ('result'=>"IMG_UPLOAD_ERROR_IMAGE_TO_BIG");
		exit (json_encode($arr));
	}
		$name = $_FILES['img']['name'];
		$dot = strrpos($name, ".");
		$dot = strlen($name) - $dot;
		$dot = -$dot;
		$ext = substr($name, $dot);
    if(move_uploaded_file($_FILES['img']['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . "/ivz2/uploadimages/" . $id . $ext)){
    	$arr = array ('result'=>'IMG_UPLOAD_OK','name'=> $id . $ext);
			echo json_encode($arr);
    }	else {
    	$arr = array ('result'=>"IMG_UPLOAD_ERROR_1: " . $_FILES['img']['tmp_name']);
			exit (json_encode($arr));    	
    }
} else {
		$arr = array ('result'=>"IMG_UPLOAD_ERROR_2");
		exit (json_encode($arr));    	
}
?>