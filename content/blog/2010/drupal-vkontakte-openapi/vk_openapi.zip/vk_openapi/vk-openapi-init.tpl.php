<div id="vk_api_transport"></div>
<script type="text/javascript">
  window.vkAsyncInit = function() {
    //VK.Observer.subscribe('auth.login', function(response) {
    //  alert('user is logged in');
      //loginOpenAPI();
      //if(window.location != baseURL + 'vk/login/') {
      //  window.location = baseURL + 'vk/login/';
      //}
    //});
    
    //VK.Observer.subscribe('auth.logout', function() {
    //   //console.log('logout');
    //});

    VK.init({
      apiId: <?php print $apiID; ?>,
      nameTransportPath: "<?php print $path; ?>"
    });
    
    VK.UI.button('vk_login');
	el = document.getElementById('vk_login');
	$('#vk_login tr td:nth-child(2) div div').html('Войти');
	$('#vk_login tr td:nth-child(4) div div').html('Контакте');

  };

  (function() {
    var el = document.createElement("script");
    el.type = "text/javascript";
    el.charset = "windows-1251";
    el.src = "http://vkontakte.ru/js/api/openapi.js";
    el.async = true;
    document.getElementById("vk_api_transport").appendChild(el);
  }());
</script>