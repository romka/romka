var
  vk_members_data = {},
  lastCommentsResponse,
  lastCommentsPage = null,
  baseURL = window.location.protocol + '//' + window.location.hostname + '/';

function array_unique(ar){
  if (ar.length && typeof ar !== 'string') {
    var sorter = {};
    var out = [];
    for (var i=0, j=ar.length; i<j; i++) {
      if(!sorter[ar[i]+typeof ar[i]]){
        out.push(ar[i]);
        sorter[ar[i]+typeof ar[i]]=true;
      }
    }
  }
  return out || ar;
}

function doLogin() {
  VK.Auth.login(getInitData);
}
function doLogout() {
  VK.Auth.logout(logoutOpenAPI);
}
function loginOpenAPI() {
  getInitData();
}
function logoutOpenAPI() {
  /*window.location.reload();*/
  window.location = baseURL;
}
function getInitData() {
  var code;
  //*
  code = 'return {';
  code += 'me: API.getProfiles({uids: API.getVariable({key: 1280}), fields: "photo,timezone"})[0]';
  code += '};';
  VK.Api.call('execute', {'code': code}, onGetInitData);
  //*/
  //VK.Api.call('getProfiles', {uids: API.getVariable({key: 1280}), fields: "photo,timezone"}, onGetInitData);
}
function onGetInitData(data) {
  var r, i, j, html;
  if (data.response) {
    r = data.response;
    /* Insert user info */
    if (r.me) {
      if(window.location != baseURL + 'vk/login/' + r.me.uid + '/' + r.me.first_name + '/' + r.me.last_name) {
        window.location = baseURL + 'vk/login/' + r.me.uid + '/' + r.me.first_name + '/' + r.me.last_name;
      }
    }    
  } else {
    window.location = baseURL + 'vk/login/error';
  }
}