function add_link_form() {
	$("div#adaptive_menu_add_link").animate({opacity: 0}, function(){$("div#adaptive_menu_add_link").html("<div id=\"adaptive_menu_form\"><form enctype=\"multipart/form-data\" onsubmit=\"return false;\"><input name=\"adaptive_menu_link\"><input type=\"submit\" value=\">>\" onclick=\"javascript:save_link(this.form.adaptive_menu_link.value)\" id=\"adaptive_menu_button\"></form></div>").animate({opacity: 1});});
	sam_edit = true;
	initDrag();
}

function save_link(lnk){
	$("#adaptive_menu_button").css({"background":"url(/sites/all/modules/sam_adaptive_menu/ajax-loader.gif) no-repeat 50% 50%"});
	$.ajax({
		  	 		type: "POST",
 				 		url: sam_url + "adaptive_menu/ajax",
 				 		dataType: 'json',
 				 		timeout: 5000,
 				 		data: "link=" + lnk,
 				 		success: function(data){$('table#amtable').append(data.result);$("#adaptive_menu_button").css({"background":""});$("div#adaptive_menu_add_link").html('<a onclick="javascript:add_link_form()" href="javascript:{}">Add link/edit links</a>');initDrag();},
 				 		error: function(data){$('table#amtable').append('Ошибка! ' + data.result);$("#adaptive_menu_button").css({"background":""});}
 			 	});
}

function delete_link(mid, uid){
	$.ajax({
		  	 		type: "POST",
 				 		url: sam_url + "adaptive_menu/delete",
 				 		dataType: 'json',
 				 		timeout: 5000,
 				 		data: "mid=" + mid,
 				 		success: function(data){$('td#am-' + uid + '-' + mid).css({display: "none"});}
 			 	});
}

function edit_link(mid, uid, ttle){
	$("td#am-" + uid + "-" + mid).animate({opacity: 0}, function(){$("td#am-" + uid + "-" + mid).html("<div id=\"adaptive_menu_form\"><form enctype=\"multipart/form-data\" onsubmit=\"return false;\"><input name=\"adaptive_menu_title_" + mid + "\" value=\"" + ttle + "\"><input type=\"submit\" value=\">>\" onclick=\"javascript:update_link(this.form.adaptive_menu_title_" + mid + ".value, " + mid + ", " + uid + ")\" id=\"adaptive_menu_update_button_" + mid + "\"></form></div>").animate({opacity: 1});});
}

function update_link(txt, mid, uid) {
		$.ajax({
		  	 		type: "POST",
 				 		url: sam_url + "adaptive_menu/update",
 				 		dataType: 'json',
 				 		timeout: 5000,
 				 		data: "mid=" + mid + "&txt=" + txt,
 				 		success: function(data){$('tr#samam_tr_' + mid).replaceWith(data.result);initDrag();}
 			 	}); 		
}

function showDEbuttons(uid, mid) {
	if(sam_edit == true)$("span#sp-" + uid + "-" + mid).css({display: ""});
}

function hideDEbuttons(uid, mid) {
	if(sam_edit == true)$("span#sp-" + uid + "-" + mid).css({display: "none"});
}

function resort(table, row) {
  var rows = table.tBodies[0].rows;
  var w = "";
  for (var i = 0; i < rows.length; i++) {
    w += rows[i].id + ";";
  }

  $.ajax({
		  	 		type: "POST",
 				 		url: sam_url + "adaptive_menu/resort",
 				 		dataType: 'json',
 				 		timeout: 5000,
 				 		data: "w=" + w
 			 	});
}

function initDrag() {
  $("#amtable").tableDnD({
        onDrop: function(table, row) {
            resort(table, row);
        },
        onDragClass: "showDragHandle"
      }
  );
  
	$("#amtable tr").hover(function() {
        $(this).addClass('showDragHandle');
  }, function() {
        $(this).removeClass('showDragHandle');
  });
}

$(document).ready(function(){
	$("span.sp").css({display: "none"});
	if(sam_edit == true) {
	  alert("456");
	  $("#amtable tr").hover(function() {
	        alert("123");
          $(this.cells[1]).addClass('showDragHandle');
    }, function() {
          $(this.cells[1]).removeClass('showDragHandle');
    });
	}
});

